/** 
*  @file smsg.hpp
*  Slamball PC test program for firmware development.
*  Top level class for the slamball_pc_tester.
*
*  WARNING:
*  This code is provided for example purpose only.  There is no guarantee for 
*  correct operation in any manner.
*/
#ifndef _SMSG_H_
#define _SMSG_H_

#include <windows.h>
#include <stdint.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <iostream>
#include <string>
#include <vector>
#include "dataLogger_timer.h"

/**
 * \typedef MessageType_t
 * \brief Identify the different Outpour outgoing messages 
 *        identifiers.
 */
typedef enum messageType {
	MSG_TYPE_FA = 0x00,
	MSG_TYPE_DAILY = 0x01,
	MSG_TYPE_WEEKLY = 0x02,
	MSG_TYPE_OTAREPLY = 0x03,
	MSG_TYPE_RETRYBYTE = 0x04,
	MSG_TYPE_CHECKIN = 0x05,
    MSG_TYPE_DEBUG_PAD_STATS = 0x10,
} MessageType_t;

/**
 * \typedef OtaOpcode_t 
 * \brief Identify each possible incomming Outpour OTA opcode.
 */
typedef enum otaOpcodes_e {
    OTA_OPCODE_GMT_CLOCKSET = 0x01,
    OTA_OPCODE_LOCAL_OFFSET = 0x02,
    OTA_OPCODE_RESET_ALL = 0x03,
    OTA_OPCODE_RESET_RED_FLAG = 0x04,
    OTA_OPCODE_ACTIVATE_DEVICE = 0x05,
    OTA_OPCODE_SILENCE_DEVICE = 0x06,
    OTA_OPCODE_UPDATE_CONSTANTS = 0x07,
    OTA_OPCODE_RESET_DEVICE = 0x08
} OtaOpcode_t;

/**
 * \typedef modem_command_t
 * \brief These are the SIM900 BodyTrace Command Messsage Types
 */
typedef enum modem_command_e {
    M_COMMAND_PING = 0x00,                    /**< PING */
    M_COMMAND_MODEM_INFO = 0x1,               /**< MODEM INFO */
    M_COMMAND_MODEM_STATUS = 0x2,             /**< MODEM STATUS */
    M_COMMAND_MESSAGE_STATUS = 0x3,           /**< MESSAGE STATUS */
    M_COMMAND_SEND_TEST = 0x20,               /**< SEND TEST */
    M_COMMAND_SEND_DATA = 0x40,               /**< SEND DATA */
    M_COMMAND_GET_INCOMING_PARTIAL = 0x42,    /**< GET INCOMING PARTIAL */
    M_COMMAND_DELETE_INCOMING = 0x43,         /**< DELETE INCOMING */
    M_COMMAND_SEND_DEBUG_DATA = 0x50,         /**< SEND DEBUG DATA - FOR OUTPUT INTERNAL DEBUG ONLY */
    M_COMMAND_POWER_OFF = 0xe0,               /**< POWER OFF */
} modem_command_t;

#define TOTAL_PADS 6

typedef struct sensorStats_s {
    uint16_t lastMeasFlowRateInMl;       /**< Last flow rate calculated */
    uint8_t numOfSubmergedPads;          /**< Number of pads submerged for this meas */
    uint8_t submergedPadsBitMask;        /**< Which pads are submerged for this meas */
    uint16_t secondsOfNoWater;           /**< How many seconds of no water detected */
    uint16_t unknowns;                   /**< Overall count of unknown case seed (skipped pad) */
    uint16_t pad5Wrong;                  /**< pad5 incorrectly detected */
    uint16_t padCounts[TOTAL_PADS];      /**< holds raw cap reading for each pad */
    uint16_t pad_max[TOTAL_PADS];        /**< Per pad max measured cap meas seen */
    uint16_t pad_min[TOTAL_PADS];        /**< Per pad min measured cap meas seen */
    int16_t  padMeasDelta[TOTAL_PADS];   /**< holds diff between max and cap reading */
    uint16_t pad_submerged[TOTAL_PADS];  /**< Per pad count of submerged */
    uint16_t pad_max1_array[TOTAL_PADS]; /**< per-hour max compare array */
    uint16_t pad_max2_array[TOTAL_PADS]; /**< per-hour max compare array */
} sensorStats_t;

class OpLogger {

public:
    OpLogger(void) {
        m_ComportNumber = 1;
        m_ComportIsOpen = false;
        m_readingCount = 0;
    }

    ~OpLogger(void) {
    }

    /**
     *  Main routine for OpLogger. Never returns.
     */
    void Exec (void);

    /**
     *  Set the comport number to use
     * @param comport_number - valid comport number (1-256)
     */
    void setComport(int comport_number) {
        m_ComportNumber = comport_number;
    }

private:

    typedef enum {
        LOOKING_FOR_PACKET_START,
        LOOKING_FOR_MODEM_CMD,
        LOOKING_FOR_PACKET_LENGTH,
        LOOKING_FOR_PACKET_VALUE_ONE,
        LOOKING_FOR_MSG_TYPE,
        LOOKING_FOR_DATA_END,
        LOOKING_FOR_PACKET_END,
    } parseState_t;

    static const int RX_BUF_SIZE = 1024;

    bool captureOnePacket(void); 
	void processOpPacket(void);
    void packetParseInit(void);
    void printRawPacket(void);
    void copyPadStatsFromPacketVector (void);

    void printPadStats(uint64_t elapsedTime);
    bool checkForValidModemCmd(uint8_t rxByte);
    bool checkForValidMsgType(uint8_t rxByte);

    void LogWriteData(uint64_t elapsedTime);
    void LogWriteNote(char *noteP);
    int LogOpenDataFile(void);
    void LogCloseDataFile(void);

    FILE *m_LogFileHandle;
    uint32_t m_LoggingRate;
    uint32_t m_LogEntryNumber;
    TestTimer m_LogTimer;
    uint64_t m_ElapsedTime;

    int m_ComportNumber;
    bool m_ComportIsOpen;
    char m_ConsoleInputBuffer[80];
    unsigned char msgRxBuffer[RX_BUF_SIZE];
    int m_readingCount;
    sensorStats_t m_sensorStats;
    parseState_t m_parseState;

    int m_msgRxBufIndex;
    int m_msgRxBytes;
    int m_packetIndex;
    int m_packetDataIndex;
    int m_packetLength;
    int m_packetModemCmd;
    int m_packetOutpourMsgType;
    bool m_packetCaptureReady;
    std::vector<uint8_t> m_packetVector;

};

void smsg_find_com_ports(void);
int smsg_find_first_com_port(void);
int smsg_init_port(int comPortNumber);
char smsg_tx(unsigned char *msg_ptr, unsigned short len);
int smsg_get_message(unsigned char *bufP, int bufSize, int timeout, bool dump);
void smsg_rx_flush(void);
int smsg_get_rxque_level(void);

#endif

