/** 
*  @file smsg.cpp
*  Slamball PC test program for firmware development.  This
*  Module contains the main thread of the program.
*
*
*  WARNING:
*  This code is provided for example purpose only.  There is no guarantee for 
*  correct operation in any manner.
*/

#include "dataLogger_exec.hpp"

void OpLogger::Exec(void) {

    bool doExit = false;

    // Open the com port
    if (!m_ComportIsOpen) {
        smsg_init_port(m_ComportNumber);
        m_ComportIsOpen = true;
    }

    // Flush serial rx queue
    smsg_rx_flush();

    packetParseInit();
    m_LogTimer.ResetStartTimestamp();

    if (!doExit) {
        if (LogOpenDataFile() != 0) {
            doExit = true;
        }
    }

    while (!doExit) {
        while (!_kbhit()) {
            // get response
            m_msgRxBytes = smsg_get_message(&msgRxBuffer[0], (int)128, (int)10000, false);
            if (m_msgRxBytes > 0) {
                m_msgRxBufIndex = 0;
                while (captureOnePacket() || m_packetCaptureReady) {

                    if (m_packetCaptureReady) {
                        printRawPacket();
#if 1
                        switch (m_packetModemCmd) {
                        case M_COMMAND_PING:                 /**< 00=PING */
                        case M_COMMAND_MODEM_INFO:           /**< 01=MODEM INFO */
                        case M_COMMAND_MODEM_STATUS:         /**< 02=MODEM STATUS */
                        case M_COMMAND_MESSAGE_STATUS:       /**< 03=MESSAGE STATUS */
                        case M_COMMAND_SEND_TEST:            /**< 0x20=SEND TEST */
                        case M_COMMAND_SEND_DATA:            /**< 0x40=SEND DATA */
                        case M_COMMAND_GET_INCOMING_PARTIAL: /**< 0x42=GET INCOMING PARTIAL */
                        case M_COMMAND_DELETE_INCOMING:      /**< 0x43=DELETE INCOMING */
                        case M_COMMAND_POWER_OFF:            /**< 0xe0= POWER OFF */
                            break;
                        case M_COMMAND_SEND_DEBUG_DATA:      /**< 0x50=SEND DEBUG DATA - FOR OUTPUT INTERNAL DEBUG ONLY */
                            processOpPacket();
                            break;
                        }
#endif
                        packetParseInit();
                    }
                } // end while
            }
        }
    }

    printf("Exit Logger Exec\n");
}

void OpLogger::printRawPacket(void) {
    std::vector<uint8_t>::const_iterator it;
    std::cout << std::endl;
    for (it = m_packetVector.begin(); it != m_packetVector.end(); ++it) {
        // std::cout << std::hex << std::setw(2) << *it << ' ';
        uint8_t val = *it;
        printf("%02.2X ", val);

        // std::cout << std::dec << val << ",";
    }
    std::cout << std::endl;
}

void OpLogger::copyPadStatsFromPacketVector (void) {
    uint8_t *stP = (uint8_t *)&m_sensorStats;
    for (int i=0;i<sizeof(sensorStats_t);i++) {
        *stP++ = m_packetVector[i+8];
    }
}

void OpLogger::processOpPacket(void) {
    switch (m_packetOutpourMsgType) {
    case MSG_TYPE_FA: //  = 0x00,
    case MSG_TYPE_DAILY: //  = 0x01,
    case MSG_TYPE_WEEKLY: //  = 0x02,
    case MSG_TYPE_OTAREPLY: //  = 0x03,
    case MSG_TYPE_RETRYBYTE: //  = 0x04,
    case MSG_TYPE_CHECKIN: //  = 0x05,
        break;
    case MSG_TYPE_DEBUG_PAD_STATS: //  = 0x10,
        copyPadStatsFromPacketVector ();
        uint64_t m_ElapsedTime = m_LogTimer.GetElapsedMillisec();
        printPadStats(m_ElapsedTime);
        LogWriteData(m_ElapsedTime);
        break;
    }
}

/**
* \brief Look for the pieces of the packet to detect the start, 
*        verify that it is a packet, and capture until the end.
* 
* @return bool Returns true if a complete packet was captured. 
*/
bool OpLogger::captureOnePacket(void) {
    bool ready = false;
    do {
        switch (m_parseState) {
        case LOOKING_FOR_PACKET_START:
            for (; m_msgRxBufIndex < m_msgRxBytes;) {
                uint8_t rxByte = msgRxBuffer[m_msgRxBufIndex++];
                if (rxByte == 0x3C) {
                    m_packetVector.push_back(rxByte);
                    m_packetIndex++;
                    m_parseState = LOOKING_FOR_MODEM_CMD;
                    break;
                }
            }
            break;
        case LOOKING_FOR_MODEM_CMD:
            // The modem command byte is at offset 1 of the packet
            for (; m_msgRxBufIndex < m_msgRxBytes;) {
                uint8_t rxByte = msgRxBuffer[m_msgRxBufIndex++];
                m_packetVector.push_back(rxByte);
                if ((m_packetIndex++ == 1) && (checkForValidModemCmd(rxByte) == true)) {
                    m_packetModemCmd = rxByte;

                    switch (rxByte) {
                    case M_COMMAND_PING:                 /**< 00=PING */
                    case M_COMMAND_MODEM_INFO:           /**< 01=MODEM INFO */
                    case M_COMMAND_MODEM_STATUS:         /**< 02=MODEM STATUS */
                    case M_COMMAND_MESSAGE_STATUS:       /**< 03=MESSAGE STATUS */
                    case M_COMMAND_SEND_TEST:            /**< 0x20=SEND TEST */
                    case M_COMMAND_GET_INCOMING_PARTIAL: /**< 0x42=GET INCOMING PARTIAL */
                    case M_COMMAND_DELETE_INCOMING:      /**< 0x43=DELETE INCOMING */
                    case M_COMMAND_POWER_OFF:            /**< 0xe0= POWER OFF */
                        m_parseState = LOOKING_FOR_PACKET_END;
                        break;

                    case M_COMMAND_SEND_DATA:            /**< 0x40=SEND DATA */
                    case M_COMMAND_SEND_DEBUG_DATA:      /**< 0x50=SEND DEBUG DATA - FOR OUTPUT INTERNAL DEBUG ONLY */
                        m_parseState = LOOKING_FOR_PACKET_LENGTH;
                        break;
                    }

                    break;
                } else {
                    packetParseInit();
                    break;
                }
            }
            break;
        case LOOKING_FOR_PACKET_LENGTH:
            // The packet length is at offset 5
            for (; m_msgRxBufIndex < m_msgRxBytes;) {
                uint8_t rxByte = msgRxBuffer[m_msgRxBufIndex++];
                m_packetVector.push_back(rxByte);
                if (m_packetIndex++ == 5) {
                    m_packetLength = rxByte;
                    // Account for header, CRC bytes and end byte (h=5,crc=2,end=1)
                    m_packetLength += 8;
                    m_parseState = LOOKING_FOR_PACKET_VALUE_ONE;
                    break;
                }
            }
            break;
        case LOOKING_FOR_PACKET_VALUE_ONE:
            // A constant of 0x1 is at offset 6
            for (; m_msgRxBufIndex < m_msgRxBytes;) {
                uint8_t rxByte = msgRxBuffer[m_msgRxBufIndex++];
                m_packetVector.push_back(rxByte);
                if ((m_packetIndex++ == 6) && (rxByte == 0x1)) {
                    m_parseState = LOOKING_FOR_MSG_TYPE;
                    break;
                } else {
                    packetParseInit();
                    break;
                }
            }
            break;
        case LOOKING_FOR_MSG_TYPE:
            // The outpour message type is at offset 7
            for (; m_msgRxBufIndex < m_msgRxBytes;) {
                uint8_t rxByte = msgRxBuffer[m_msgRxBufIndex++];
                m_packetVector.push_back(rxByte);
                if ((m_packetIndex++ == 7) && (checkForValidMsgType(rxByte) == true)) {
                    m_packetOutpourMsgType = rxByte;
                    m_parseState = LOOKING_FOR_DATA_END;
                    break;
                } else {
                    packetParseInit();
                    break;
                }
            }
            break;
        case LOOKING_FOR_DATA_END:
            // Get remaining portion of packet
            for (; m_msgRxBufIndex < m_msgRxBytes;) {
                uint8_t rxByte = msgRxBuffer[m_msgRxBufIndex++];
                m_packetVector.push_back(rxByte);
                if ((m_packetIndex++ == m_packetLength) && (rxByte == 0x3B)) {
                    ready = true;
                    m_packetCaptureReady = true;
                    break;
                } else if (m_packetIndex > m_packetLength) {
                    packetParseInit();
                    break;
                }
            }
            break;
        case LOOKING_FOR_PACKET_END:
            // Get remaining portion of packet
            for (; m_msgRxBufIndex < m_msgRxBytes;) {
                uint8_t rxByte = msgRxBuffer[m_msgRxBufIndex++];
                m_packetVector.push_back(rxByte);
                if (rxByte == 0x3B) {
                    ready = true;
                    m_packetCaptureReady = true;
                    break;
                }
            }
            break;

        } // end case
    } while ((m_msgRxBufIndex < m_msgRxBytes) && !ready);

    return (m_msgRxBufIndex < m_msgRxBytes);
}

void OpLogger::packetParseInit(void) {
    m_parseState = LOOKING_FOR_PACKET_START;
    m_packetIndex = 0;
    m_packetDataIndex = 0;
    m_packetCaptureReady = false;
    m_packetVector.clear();
}

/*
Example Debug Packet
0x3c 0x50 0x00 0x00 0x00 0x48 0x01 0x10 0x6a 0x01 0x01 0x01 0x00 0x00 0xc2 0x9f 0x8d 0xa9 0x8b 0xa5
0x3d 0xab 0x2a 0xb1 0xf0 0xbf 0xc2 0x9f 0x8d 0xa9 0x9a 0xa5 0x47 0xab 0x2a 0xb1 0xf6 0xbf 0xc0 0x9f
0x88 0xa9 0x8b 0xa5 0x38 0xab 0x1b 0xb1 0xe7 0xbf 0x00 0x03 0x29 0x00 0x2a 0x00 0x22 0x00 0x21 0x00
0x28 0x00 0x03 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x03 0x00 0x00 0x00 0x01 0x40
0x3b
*/

bool OpLogger::checkForValidModemCmd(uint8_t rxByte) {
    bool validCmd = false;
    printf("\n\n GOT MODEM COMMAND: 0x%x\n\n", rxByte);
    switch (rxByte) {
    case M_COMMAND_PING:                 /**< 00=PING */
    case M_COMMAND_MODEM_INFO:           /**< 01=MODEM INFO */
    case M_COMMAND_MODEM_STATUS:         /**< 02=MODEM STATUS */
    case M_COMMAND_MESSAGE_STATUS:       /**< 03=MESSAGE STATUS */
    case M_COMMAND_SEND_TEST:            /**< 0x20=SEND TEST */
    case M_COMMAND_SEND_DATA:            /**< 0x40=SEND DATA */
    case M_COMMAND_GET_INCOMING_PARTIAL: /**< 0x42=GET INCOMING PARTIAL */
    case M_COMMAND_DELETE_INCOMING:      /**< 0x43=DELETE INCOMING */
    case M_COMMAND_POWER_OFF:            /**< 0xe0= POWER OFF */
    case M_COMMAND_SEND_DEBUG_DATA:      /**< 0x50=SEND DEBUG DATA - FOR OUTPUT INTERNAL DEBUG ONLY */
        validCmd = true;
        break;
    }
    return validCmd;
}

bool OpLogger::checkForValidMsgType(uint8_t rxByte) {
    bool validMsgType = false;
    switch (rxByte) {
    case MSG_TYPE_FA: //  = 0x00,
    case MSG_TYPE_DAILY: //  = 0x01,
    case MSG_TYPE_WEEKLY: //  = 0x02,
    case MSG_TYPE_OTAREPLY: //  = 0x03,
    case MSG_TYPE_RETRYBYTE: //  = 0x04,
    case MSG_TYPE_CHECKIN: //  = 0x05,
    case MSG_TYPE_DEBUG_PAD_STATS: //  = 0x10,
        validMsgType = true;
        break;
    }
    return validMsgType;
}

void OpLogger::printPadStats(uint64_t elapsedTime) {
    sensorStats_t *stP = &m_sensorStats;
    printf("%u, %llu\n"
           "%06hu, %06u, %06u, %06hu, %06hu, %06hu\n"
           "%06hu, %06hu, %06hu, %06hu, %06hu, %06hu [Counts]\n"  // padCounts
           "%06hu, %06hu, %06hu, %06hu, %06hu, %06hu [Max] \n"  // pad_max
           "%06hu, %06hu, %06hu, %06hu, %06hu, %06hu [Min] \n"  // pad_min
           "%06hu, %06hu, %06hu, %06hu, %06hu, %06hu [Delta] \n"  // padMeasDelta
           "%06hu, %06hu, %06hu, %06hu, %06hu, %06hu [Max1Array] \n"  // pad_max1_array
           "%06hu, %06hu, %06hu, %06hu, %06hu, %06hu [Max2Array] \n"  // pad_max2_array
           "\n\n",

           m_LogEntryNumber, elapsedTime,

           stP->lastMeasFlowRateInMl, stP->numOfSubmergedPads, stP->submergedPadsBitMask, 
           stP->secondsOfNoWater, stP->unknowns, stP->pad5Wrong,

           stP->padCounts[0], stP->padCounts[1], stP->padCounts[2], 
           stP->padCounts[3], stP->padCounts[4], stP->padCounts[5],

           stP->pad_max[0], stP->pad_max[1], stP->pad_max[2], 
           stP->pad_max[3], stP->pad_max[4], stP->pad_max[5],

           stP->pad_min[0], stP->pad_min[1], stP->pad_min[2], 
           stP->pad_min[3], stP->pad_min[4], stP->pad_min[5],

           stP->padMeasDelta[0], stP->padMeasDelta[1], stP->padMeasDelta[2], 
           stP->padMeasDelta[3], stP->padMeasDelta[4], stP->padMeasDelta[5],

           stP->pad_max1_array[0], stP->pad_max1_array[1], stP->pad_max1_array[2], 
           stP->pad_max1_array[3], stP->pad_max1_array[4], stP->pad_max1_array[5],

           stP->pad_max2_array[0], stP->pad_max2_array[1], stP->pad_max2_array[2], 
           stP->pad_max2_array[3], stP->pad_max2_array[4], stP->pad_max2_array[5] 
           );
}

#if 0
typedef struct sensorStats_s {
    uint16_t lastMeasFlowRateInMl;     /**< Last flow rate calculated */
    uint8_t numOfSubmergedPads;        /**< Number of pads submerged for this meas */
    uint8_t submergedPadsBitMask;      /**< Which pads are submerged for this meas */
    uint16_t secondsOfNoWater;         /**< How many seconds of no water detected */
    uint16_t padCounts[TOTAL_PADS];     /**< holds raw cap reading for each pad */
    uint16_t pad_max[TOTAL_PADS];       /**< Per pad max measured cap meas seen */
    uint16_t pad_min[TOTAL_PADS];       /**< Per pad min measured cap meas seen */
    int16_t  padMeasDelta[TOTAL_PADS];  /**< holds diff between max and cap reading */
    uint16_t pad_submerged[TOTAL_PADS]; /**< Per pad count of submerged */
    uint16_t unknowns;                  /**< Overall count of unknown case seed (skipped pad) */
}
sensorStats_t;
#endif

void OpLogger::LogWriteData(uint64_t elapsedTime) {
    sensorStats_t *stP = &m_sensorStats;
    if (m_LogFileHandle != NULL) {
        fprintf(m_LogFileHandle,
                "%u,%llu,"
                "%u,%u,%u,%u,%u,%u"
                "%u,%u,%u,%u,%u,%u,"  // padCounts
                "%u,%u,%u,%u,%u,%u,"  // pad_max
                "%u,%u,%u,%u,%u,%u,"  // pad_min
                "%u,%u,%u,%u,%u,%u,"  // padMeasDelta
                "%u,%u,%u,%u,%u,%u,"  // pad_max1_array
                "%u,%u,%u,%u,%u,%u,"  // pad_max2_array
                "\n",
                m_LogEntryNumber++, elapsedTime,

                stP->lastMeasFlowRateInMl, stP->numOfSubmergedPads, stP->submergedPadsBitMask, 
                stP->secondsOfNoWater, stP->unknowns, stP->pad5Wrong,

                stP->padCounts[0], stP->padCounts[1], stP->padCounts[2], 
                stP->padCounts[3], stP->padCounts[4], stP->padCounts[5],

                stP->pad_max[0], stP->pad_max[1], stP->pad_max[2], 
                stP->pad_max[3], stP->pad_max[4], stP->pad_max[5],

                stP->pad_min[0], stP->pad_min[1], stP->pad_min[2], 
                stP->pad_min[3], stP->pad_min[4], stP->pad_min[5],

                stP->padMeasDelta[0], stP->padMeasDelta[1], stP->padMeasDelta[2], 
                stP->padMeasDelta[3], stP->padMeasDelta[4], stP->padMeasDelta[5],

                stP->pad_max1_array[0], stP->pad_max1_array[1], stP->pad_max1_array[2], 
                stP->pad_max1_array[3], stP->pad_max1_array[4], stP->pad_max1_array[5],

                stP->pad_max2_array[0], stP->pad_max2_array[1], stP->pad_max2_array[2], 
                stP->pad_max2_array[3], stP->pad_max2_array[4], stP->pad_max2_array[5] 
                );
    }
}

/**
 * \brief Open the data log file
 * 
 */
int OpLogger::LogOpenDataFile(void) {
    int status = 0;
    std::string name;
    SYSTEMTIME st;
    // Create the logs directory
    if (!CreateDirectory(".\\logs", NULL)) {
        if (GetLastError() == ERROR_ALREADY_EXISTS) {
            // directory already exists
        } else {
            // creation failed due to some other reason
            status = -1;
        }
    }

    // Attempt to open the file and write header
    if (status == 0) {

        m_LogEntryNumber = 0;
        GetLocalTime(&st);
        char buf[1024];

#if 0
        if (m_TestId.length() > 0) {
            // Name format is log_yyyy-mm-dd_hhmmss_testId
            sprintf(buf, ".\\logs\\log_%4d-%02d-%02d_%02d%02d%02d_%s.csv",
                    st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, m_TestId.toLocal8Bit().constData());
        } else {
            // Name format is log_yyyy-mm-dd_hhmmss
            sprintf(buf, ".\\logs\\log_%4d-%02d-%02d_%02d%02d%02d.csv",
                    st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
        }
#endif
        // Name format is log_yyyy-mm-dd_hhmmss
        sprintf(buf, ".\\logs\\log_%4d-%02d-%02d_%02d%02d%02d.csv",
                st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);

        m_LogFileHandle = fopen(buf, "w");
        if (m_LogFileHandle) {

            sprintf(buf, "Run Date,%d/%d/%d %02d:%02d:%02d\n", st.wMonth, st.wDay, st.wYear, st.wHour, st.wMinute, st.wSecond);
            fprintf(m_LogFileHandle, buf);

#if 0
            if (m_TestId.length() > 0) {
                sprintf(buf, "Test ID,%s\n", m_TestId.toLocal8Bit().constData());
                fprintf(m_LogFileHandle, buf);
            }

            if (m_TestNote.length() > 0) {
                sprintf(buf, "Test Note,%s\n", m_TestNote.toLocal8Bit().constData());
                fprintf(m_LogFileHandle, buf);
            }
#endif

            fprintf(m_LogFileHandle,
                    "%s,%s,"
                    "%s,%s,%s,%s,%s,%s"
                    "%s,%s,%s,%s,%s,%s,"  // padCounts
                    "%s,%s,%s,%s,%s,%s,"  // pad_max
                    "%s,%s,%s,%s,%s,%s,"  // pad_min
                    "%s,%s,%s,%s,%s,%s,"  // padMeasDelta
                    "%s,%s,%s,%s,%s,%s,"  // padMax1Array
                    "%s,%s,%s,%s,%s,%s,"  // padMax2Array
                    "\n",

                    "m_LogEntryNumber", "elapsedTime",

                    "lastMeasFlowRateInMl", "numOfSubmergedPads", "submergedPadsBitMask", 
                    "secondsOfNoWater", "unknowns", "pad5wrond",

                    "padCounts[0]", "padCounts[1]", "padCounts[2]", "padCounts[3]", "padCounts[4]", "padCounts[5]",

                    "pad_max[0]", "pad_max[1]", "pad_max[2]", "pad_max[3]", "pad_max[4]", "pad_max[5]",

                    "pad_min[0]", "pad_min[1]", "pad_min[2]", "pad_min[3]", "pad_min[4]", "pad_min[5]",

                    "padMeasDelta[0]", "padMeasDelta[1]", "padMeasDelta[2]", 
                    "padMeasDelta[3]", "padMeasDelta[4]", "padMeasDelta[5]",

                    "padMax1Array[0]", "padMax1Array[1]", "padMax1Array[2]", 
                    "padMax1Array[3]", "padMax1Array[4]", "padMax1Array[5]",

                    "padMax2Array[0]", "padMax2Array[1]", "padMax2Array[2]", 
                    "padMax2Array[3]", "padMax2Array[4]", "padMax2Array[5]"

                    );

        } else {
            std::cout << "ERROR:  Could not open file for logging: " << buf << std::endl;
            status = -1;
        }
    }

    return status;
}

void OpLogger::LogWriteNote(char *noteP) {
    if (!m_LogFileHandle) {
        return;
    }
    fprintf(m_LogFileHandle, noteP);
}

/**
 * \brief Close the output data file used to save run data
 * 
 */
void OpLogger::LogCloseDataFile(void) {
    if (m_LogFileHandle != NULL) {
        fclose(m_LogFileHandle);
    }
    m_LogFileHandle = NULL;
}

/*******************************************************************************
*
*  Confirm entry
*
*******************************************************************************/
static bool confirm_entry(const char *msg) {
    char input_buf[128];
    printf("\nconfirm %s [yY]: ", msg);
    gets(input_buf);
    if ((strlen(input_buf) != 1) ||
        ((input_buf[0] != 'y') && (input_buf[0] != 'Y'))) {
        return false;
    }
    return true;
}

